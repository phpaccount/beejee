<form method="POST" action="/login/auth">
  <div class="form-group">
    <label for="username">Имя пользователя:</label>
    <input type="text" class="form-control" id="username" name="username" value="admin">
  </div>
  <div class="form-group">
    <label for="password">Пароль</label>
    <input type="password" class="form-control" id="password" name="password" value="123">
  </div>
  <div class="form-group">
    <button type="submit" class="btn btn-primary">Войти</button>
  </div>
</form>