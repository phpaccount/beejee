<?php

namespace Core\Lib\Image;

/**
 * PHP Exception used in the ImageResize class
 */
class ImageResizeException extends \Exception
{
	
}
